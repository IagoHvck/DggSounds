/* DggSounds — navegação não-linear, animações, demonstrações com Web Audio e quiz */
{
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const nf = (n, d = 0) => n.toLocaleString('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d });
const kb = b => b >= 1048576 ? nf(b / 1048576, 2) + ' MB' : nf(b / 1024, 1) + ' KB';
const _probe = document.createElement('span'); _probe.style.display = 'none'; document.body.appendChild(_probe);
const _cor = {}; let _corT = 0;
const cssv = n => { const now = performance.now(); if (now - _corT > 1000) { for (const k in _cor) delete _cor[k]; _corT = now; }
  if (!_cor[n]) { _probe.style.color = `var(${n})`; _cor[n] = getComputedStyle(_probe).color; } return _cor[n]; };
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = { get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };

let ctx = null;
const ac = () => { if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === 'suspended') ctx.resume(); return ctx; };
const sfx = n => { const a = new Audio('audio/sfx_' + n + '.wav'); a.volume = 0.7; a.play().catch(() => { }); };
/* som do botão: toca no instante em que qualquer botão é pressionado */
let somBotao = null, somBotaoCarregando = false;
function carregaSomBotao() {
  if (somBotao || somBotaoCarregando) return; somBotaoCarregando = true;
  fetch('audio/som_botao.wav').then(r => r.arrayBuffer()).then(b => ac().decodeAudioData(b)).then(buf => { somBotao = buf; })
    .catch(() => { somBotaoCarregando = false; });
}
function tocaSomBotao() {
  const c = ac();
  if (somBotao) { const s = c.createBufferSource(), g = c.createGain(); g.gain.value = 0.8; s.buffer = somBotao; s.connect(g); g.connect(c.destination); s.start(); }
  else { carregaSomBotao(); const a = new Audio('audio/som_botao.wav'); a.volume = 0.8; a.play().catch(() => { }); }
}
const ALVO_BOTAO = 'button, .btn, .card, .opt, .nav a';
document.addEventListener('pointerdown', e => { if (e.button === 0 && e.target.closest(ALVO_BOTAO) && !e.target.closest(ALVO_BOTAO).disabled) tocaSomBotao(); }, true);
document.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && !e.repeat && e.target.closest && e.target.closest(ALVO_BOTAO) && !e.target.disabled) tocaSomBotao(); }, true);
const icon = (id) => `<svg><use href="#${id}"/></svg>`;
function setBtn(b, on, txtOn, txtOff) { b.setAttribute('aria-pressed', on); b.innerHTML = icon(on ? 'i-stop' : 'i-play') + (on ? txtOn : txtOff); }

/* ---------- canvas com resolução real ---------- */
function canvas(cv, draw) {
  const g = cv.getContext('2d');
  const fit = () => { const r = cv.getBoundingClientRect(), d = devicePixelRatio || 1; cv.width = Math.max(1, r.width * d); cv.height = Math.max(1, r.height * d); g.setTransform(d, 0, 0, d, 0, 0); };
  const ro = new ResizeObserver(fit); ro.observe(cv); fit();
  return { g, W: () => cv.width / (devicePixelRatio || 1), H: () => cv.height / (devicePixelRatio || 1), draw };
}
const reduz = matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- ROTEADOR (navegação não-linear) ---------- */
const TELAS = ['inicio', 'som', 'digital', 'tamanho', 'formatos', 'edicao', 'midi', 'quiz', 'sobre'];
let atual = '';
const pararTudo = [];
function rota() {
  let id = location.hash.slice(1); if (!TELAS.includes(id)) id = 'inicio';
  if (id === atual) return;
  pararTudo.forEach(f => f());
  atual = id;
  $$('.tela').forEach(t => t.classList.toggle('on', t.id === 't-' + id));
  $$('.nav a').forEach(a => { a.removeAttribute('aria-current'); if (a.getAttribute('href') === '#' + id) a.setAttribute('aria-current', 'page'); });
  window.scrollTo(0, 0);
  const vis = store.get('dgg-visitados', []);
  if (!['inicio', 'sobre', 'quiz'].includes(id) && !vis.includes(id)) { vis.push(id); store.set('dgg-visitados', vis); }
  marcarVisitados();
  if (id === 'quiz' && !quiz.ativo) novoQuiz();
  const nav = $('.nav a[aria-current]'); if (nav) nav.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}
function marcarVisitados() {
  const vis = store.get('dgg-visitados', []);
  $$('#cards .card').forEach(c => {
    const id = c.getAttribute('href').slice(1);
    if (vis.includes(id) && !$('.feito', c)) c.insertAdjacentHTML('beforeend', '<span class="feito">✓ visitado</span>');
  });
}
addEventListener('hashchange', rota);

/* ---------- loop de animação (só desenha a tela visível) ---------- */
const anims = [];
function loop(t) { for (const a of anims) if (a.tela === atual) a.fn(t / 1000); if (!reduz) requestAnimationFrame(loop); }

/* ---------- INÍCIO: barras de onda (como no slide 2) ---------- */
{
  const c = canvas($('#cvHero'));
  anims.push({ tela: 'inicio', fn: t => {
    const { g } = c, W = c.W(), H = c.H(), n = Math.floor(W / 7), mid = H / 2;
    g.clearRect(0, 0, W, H);
    const vivo = trilha && trilha.on ? 1.35 : 1;
    for (let i = 0; i < n; i++) {
      const x = 14 + i * ((W - 28) / n);
      const env = Math.pow(Math.sin(Math.PI * i / n), 0.6);
      const v = Math.abs(Math.sin(i * 0.37 + t * 2.1) * 0.6 + Math.sin(i * 1.7 - t * 3.3) * 0.3 + Math.sin(i * 0.11 + t) * 0.25);
      const h = Math.max(2, v * env * (H * 0.42) * vivo);
      g.fillStyle = i % 9 === 0 ? '#eceae6' : 'rgba(236,234,230,.78)';
      g.fillRect(x, mid - h, 2, h * 2);
    }
    // amostras discretas sobre a onda
    g.fillStyle = '#ffffff';
    for (let i = 0; i < n; i += 6) {
      const x = 14 + i * ((W - 28) / n), y = mid - Math.sin(i * 0.09 + t * 1.4) * H * 0.18;
      g.beginPath(); g.arc(x + 1, y, 3.2, 0, 7); g.fill();
    }
  } });
}

/* ---------- MÓDULO 1: gerador de tons ---------- */
let tom = null;
{
  const c = canvas($('#cvSom')), rF = $('#rFreq'), rA = $('#rAmp'), sF = $('#sForma'), b = $('#bTom');
  rF.value = 447;
  const freq = () => 20 * Math.pow(1000, rF.value / 1000), amp = () => rA.value / 100;
  const upd = () => {
    const f = freq();
    $('#oFreq').textContent = nf(f, f < 100 ? 1 : 0) + ' Hz';
    $('#oAmp').textContent = rA.value + '% · ' + (amp() > 0 ? nf(20 * Math.log10(amp()), 1) + ' dBFS' : '−∞ dBFS');
    $('#oLambda').textContent = `Período T = ${nf(1000 / f, 2)} ms · comprimento de onda no ar λ = 343 / f ≈ ${nf(343 / f, 2)} m · ${f < 250 ? 'som grave' : f < 2000 ? 'som médio' : 'som agudo'}`;
    if (tom) { const t = ctx.currentTime; tom.o.frequency.setTargetAtTime(f, t, 0.02); tom.g.gain.setTargetAtTime(amp() * 0.3, t, 0.02); tom.o.type = sF.value; }
  };
  [rF, rA, sF].forEach(e => e.addEventListener('input', upd)); upd();
  const parar = () => { if (tom) { tom.g.gain.setTargetAtTime(0, ctx.currentTime, 0.02); tom.o.stop(ctx.currentTime + 0.1); tom = null; } setBtn(b, false, '', 'Tocar tom'); };
  b.addEventListener('click', () => {
    if (tom) return parar();
    const a = ac(), o = a.createOscillator(), g = a.createGain();
    o.type = sF.value; o.frequency.value = freq(); g.gain.value = 0; g.gain.setTargetAtTime(amp() * 0.3, a.currentTime, 0.02);
    o.connect(g); g.connect(a.destination); o.start(); tom = { o, g }; setBtn(b, true, 'Parar', '');
  });
  pararTudo.push(parar);
  const forma = (ph, w) => { ph -= Math.floor(ph);
    return w === 'sine' ? Math.sin(2 * Math.PI * ph) : w === 'square' ? (ph < .5 ? 1 : -1) : w === 'sawtooth' ? 2 * ph - 1 : (ph < .5 ? 4 * ph - 1 : 3 - 4 * ph); };
  anims.push({ tela: 'som', fn: t => {
    const { g } = c, W = c.W(), H = c.H(), mid = H / 2, ink = cssv('--ink'), mut = cssv('--line');
    g.clearRect(0, 0, W, H);
    g.strokeStyle = mut; g.lineWidth = 1; g.beginPath(); g.moveTo(0, mid); g.lineTo(W, mid); g.stroke();
    const ciclos = 1 + Math.log2(freq() / 20) * 1.3, A = amp() * H * 0.42, vel = tom ? 0.8 : 0.25;
    g.strokeStyle = ink; g.lineWidth = 3; g.beginPath();
    for (let x = 0; x <= W; x += 2) { const y = mid - A * forma(x / W * ciclos - t * vel, sF.value); x ? g.lineTo(x, y) : g.moveTo(x, y); }
    g.stroke();
    // partículas de ar: compressão e rarefação
    g.fillStyle = mut;
    for (let i = 0; i < 70; i++) { const x0 = i / 70 * W, dx = Math.sin(2 * Math.PI * (x0 / W * ciclos - t * vel)) * 6 * amp(); g.fillRect(x0 + dx, H - 16, 2, 8); }
  } });
}

/* ---------- MÓDULO 2: amostragem e quantização ---------- */
let dig = null;
{
  const c = canvas($('#cvDig')), rSf = $('#rSf'), rFs = $('#rFs'), rB = $('#rBits'), b = $('#bDig');
  const q = (x, bits) => { const L = Math.pow(2, bits); return Math.round((x + 1) / 2 * (L - 1)) / (L - 1) * 2 - 1; };
  const alias = (f, fs) => Math.abs(f - fs * Math.round(f / fs));
  let tm;
  const buf = () => {
    const a = ac(), sr = a.sampleRate, n = Math.floor(sr * 2), bf = a.createBuffer(1, n, sr), d = bf.getChannelData(0);
    const f = +rSf.value, fs = +rFs.value, bits = +rB.value;
    for (let i = 0; i < n; i++) { const k = Math.floor(i / sr * fs); d[i] = 0.25 * q(Math.sin(2 * Math.PI * f * k / fs), bits); }
    return bf;
  };
  const tocar = () => { const a = ac(), s = a.createBufferSource(); s.buffer = buf(); s.loop = true; s.connect(a.destination); s.start(); if (dig) dig.stop(); dig = s; };
  const upd = () => {
    const f = +rSf.value, fs = +rFs.value, bits = +rB.value;
    $('#oSf').textContent = nf(f) + ' Hz'; $('#oFs').textContent = nf(fs) + ' Hz';
    $('#oBits').textContent = `${bits} bit${bits > 1 ? 's' : ''} · ${nf(Math.pow(2, bits))} níveis`;
    const ok = f < fs / 2, n = $('#oNyq');
    n.classList.toggle('warn', !ok);
    n.innerHTML = (ok ? `<b>Nyquist respeitado:</b> fs/2 = ${nf(fs / 2)} Hz é maior que o sinal de ${nf(f)} Hz.`
      : `<b>Aliasing!</b> fs/2 = ${nf(fs / 2)} Hz é menor que ${nf(f)} Hz. O sinal vai soar como uma frequência falsa de ≈ ${nf(alias(f, fs))} Hz.`)
      + ` Faixa dinâmica com ${bits} bits ≈ ${nf(bits * 6.02, 0)} dB.`;
    clearTimeout(tm); if (dig) tm = setTimeout(tocar, 120);
  };
  [rSf, rFs, rB].forEach(e => e.addEventListener('input', upd)); upd();
  const parar = () => { if (dig) { dig.stop(); dig = null; } setBtn(b, false, '', 'Ouvir resultado'); };
  b.addEventListener('click', () => { if (dig) return parar(); tocar(); setBtn(b, true, 'Parar', ''); });
  pararTudo.push(parar);
  anims.push({ tela: 'digital', fn: () => {
    const { g } = c, W = c.W(), H = c.H(), mid = H / 2, A = H * 0.38, ink = cssv('--ink'), mut = cssv('--mut'), ln = cssv('--line');
    const f = +rSf.value, fs = +rFs.value, bits = +rB.value, per = 4 / f, X = t => 10 + t / per * (W - 20);
    g.clearRect(0, 0, W, H);
    const L = Math.pow(2, bits);
    if (L <= 64) { g.strokeStyle = ln; g.lineWidth = 1; for (let k = 0; k < L; k++) { const y = mid - A * (k / (L - 1) * 2 - 1); g.beginPath(); g.moveTo(10, y); g.lineTo(W - 10, y); g.stroke(); } }
    g.strokeStyle = mut; g.lineWidth = 2; g.globalAlpha = .55; g.beginPath();
    for (let x = 10; x <= W - 10; x++) { const t = (x - 10) / (W - 20) * per, y = mid - A * Math.sin(2 * Math.PI * f * t); x > 10 ? g.lineTo(x, y) : g.moveTo(x, y); }
    g.stroke(); g.globalAlpha = 1;
    const N = Math.floor(per * fs);
    g.strokeStyle = ink; g.lineWidth = 2.5; g.beginPath();
    for (let k = 0; k <= N; k++) { const t = k / fs, v = q(Math.sin(2 * Math.PI * f * t), bits), y = mid - A * v, x1 = X(Math.min(per, (k + 1) / fs));
      k ? g.lineTo(X(t), y) : g.moveTo(X(t), y); g.lineTo(x1, y); }
    g.stroke();
    if (N < 160) { g.fillStyle = ink; for (let k = 0; k <= N; k++) { const t = k / fs; g.beginPath(); g.arc(X(t), mid - A * q(Math.sin(2 * Math.PI * f * t), bits), 4, 0, 7); g.fill(); } }
    if (f >= fs / 2) { const fa = alias(f, fs), s = Math.sign(Math.sin(2 * Math.PI * f / fs)) || 1;
      g.setLineDash([7, 6]); g.strokeStyle = cssv('--bad'); g.lineWidth = 2; g.beginPath();
      for (let x = 10; x <= W - 10; x += 2) { const t = (x - 10) / (W - 20) * per, y = mid - A * Math.sin(2 * Math.PI * fa * t) * s; x > 10 ? g.lineTo(x, y) : g.moveTo(x, y); }
      g.stroke(); g.setLineDash([]); }
    g.fillStyle = mut; g.font = '600 13px Outfit, sans-serif';
    g.fillText(`${N + 1} amostras em ${nf(per * 1000, 2)} ms`, 14, 20);
  } });
  const T = window.DGG_TAMANHOS || {};
  const qual = [
    ['amostra_44k_16bit.wav', 'Original · 44,1 kHz · 16 bits', 'qualidade de CD'],
    ['amostra_22k_16bit.wav', '22,05 kHz · 16 bits', 'agudos acima de 11 kHz somem'],
    ['amostra_11k_8bit.wav', '11 kHz · 8 bits', 'abafado e com chiado'],
    ['amostra_8k_sem_filtro.wav', '8 kHz sem filtro anti-aliasing', 'aliasing audível'],
    ['amostra_44k_4bit.wav', '44,1 kHz · 4 bits', 'ruído de quantização'],
  ];
  $('#plQual').innerHTML = qual.map(([f, t, d]) => `<div class="pl"><b>${t}</b><em>${d} · ${kb(T[f] || 0)}</em><audio controls preload="none" src="audio/${f}"></audio></div>`).join('');
}

/* ---------- MÓDULO 3: calculadora ---------- */
{
  const ids = ['nFs', 'nBits', 'nCh', 'nDur'], pre = $('#sPre');
  const calc = () => {
    const [fs, bits, ch, dur] = ids.map(i => Math.max(0, +$('#' + i).value || 0));
    const bps = fs * bits * ch, bytes = bps * dur / 8;
    $('#oKbps').textContent = nf(bps / 1000) + ' kbps';
    $('#oMB').textContent = bytes >= 1073741824 ? nf(bytes / 1073741824, 2) + ' GB' : bytes >= 1048576 ? nf(bytes / 1048576, 1) + ' MB' : nf(bytes / 1024, 1) + ' KB';
    $('#oConta').textContent = `${nf(fs)} × ${bits} × ${ch} = ${nf(bps)} bits/s · × ${nf(dur)} s ÷ 8 = ${nf(bytes)} bytes · um MP3 de 192 kbps teria ≈ ${nf(192000 * dur / 8 / 1048576, 1)} MB`;
  };
  pre.addEventListener('change', () => { if (pre.value === 'custom') return; const [fs, b, ch] = pre.value.split(','); $('#nFs').value = fs; $('#nBits').value = b; $('#nCh').value = ch; calc(); });
  ids.forEach(i => $('#' + i).addEventListener('input', () => { pre.value = 'custom'; calc(); }));
  calc();
}

/* ---------- MÓDULO 4: formatos ---------- */
{
  const T = window.DGG_TAMANHOS || {}, base = T['amostra_44k_16bit.wav'] || 1;
  const fm = [['amostra_44k_16bit.wav', 'WAV (PCM, sem compressão)'], ['amostra.flac', 'FLAC (sem perdas)'], ['amostra_192k.mp3', 'MP3 192 kbps (com perdas)'], ['amostra_32k.mp3', 'MP3 32 kbps (compressão forte)']];
  $('#plFmt').innerHTML = fm.map(([f, t]) => { const s = T[f] || 0, p = s / base * 100;
    return `<div class="pl"><b>${t}</b><em>${kb(s)} · ${nf(p, 0)}% do WAV</em><div class="meter"><i style="width:${Math.max(p, 1)}%"></i></div><audio controls preload="none" src="audio/${f}"></audio></div>`; }).join('');
}

/* ---------- MÓDULO 5: antes × depois ---------- */
{
  const A = new Audio('audio/edicao_antes.wav'), D = new Audio('audio/edicao_depois.wav'), b = $('#bAB'), bA = $('#bAntes'), bD = $('#bDepois'), img = $('#imgAB');
  let lado = 'antes';
  const cur = () => lado === 'antes' ? A : D;
  const escolhe = l => {
    const tocando = !cur().paused, t = cur().currentTime;
    cur().pause(); lado = l; cur().currentTime = t; if (tocando) cur().play().catch(() => { });
    bA.setAttribute('aria-pressed', l === 'antes'); bD.setAttribute('aria-pressed', l === 'depois');
    img.src = 'img/onda_' + l + '.png';
  };
  bA.addEventListener('click', () => escolhe('antes')); bD.addEventListener('click', () => escolhe('depois'));
  b.addEventListener('click', () => { if (cur().paused) { cur().play().catch(() => { }); setBtn(b, true, 'Pausar', ''); } else { cur().pause(); setBtn(b, false, '', 'Tocar'); } });
  [A, D].forEach(x => x.addEventListener('ended', () => setBtn(b, false, '', 'Tocar')));
  pararTudo.push(() => { A.pause(); D.pause(); setBtn(b, false, '', 'Tocar'); });
}

/* ---------- MÓDULO 6 e TRILHA: MIDI ---------- */
const DM = window.DggMidi;
const song = DM.parse(DM.b64(window.DGG_MIDI_B64));        // trilha melódica (gerada)
const bat = DM.parse(DM.b64(window.DGG_BATERIA_B64));      // bateria composta pelo grupo no LMMS
const tocadores = {};  // id -> { p: Player, botao, txtOff }
let trilha = null;
function tocador(id, musica, opc, botao, txtOff) {
  const t = tocadores[id] || (tocadores[id] = { musica, opc, botao, txtOff, p: null });
  return t;
}
function pararMidi(exceto) {
  for (const id in tocadores) { const t = tocadores[id]; if (id === exceto || !t.p || !t.p.on) continue;
    t.p.parar(); if (t.botao.id === 'btnTrilha') t.botao.setAttribute('aria-pressed', 'false'); else setBtn(t.botao, false, '', t.txtOff); }
}
function alternar(id) {
  const t = tocadores[id], a = ac();
  if (!t.p) t.p = new DM.Player(a, t.musica, t.opc);
  if (t.p.on) { pararMidi(); syncFundo(); return; }
  pararMidi(id); if (fundo.p && fundo.p.on) fundo.p.parar(); t.p.tocar();
  if (t.botao.id === 'btnTrilha') t.botao.setAttribute('aria-pressed', 'true'); else setBtn(t.botao, true, 'Parar', '');
}
const posBat = () => { for (const id of ['bat', 'batPiano', 'trilha']) { const t = tocadores[id]; if (t && t.p && t.p.on) return t.p.posicao(); } return -1; };
{
  const T = window.DGG_TAMANHOS || {}, m = song.meta, c = canvas($('#cvMidi'));
  tocador('melodia', song, null, $('#bMidi'), 'Tocar MIDI');
  $('#bMidi').addEventListener('click', () => alternar('melodia'));
  $('#oMidiInfo').textContent = `${song.notas.length} notas · ${m.faixas} faixas · ${m.bpm} bpm · ${nf(m.duracao, 1)} s em loop`;
  const mid = T['trilha_menu.mid'] || 0, wav = T['trilha_renderizada.wav'] || 1, bm = T['bateria.mid'] || 0;
  $('#plMidi').innerHTML = `<div class="pl"><b>trilha_menu.mid</b><em>${kb(mid)}</em><div class="meter"><i style="width:${Math.max(mid / wav * 100, 0.6)}%"></i></div></div>
    <div class="pl"><b>trilha_renderizada.wav</b><em>${kb(wav)} · ${nf(wav / mid, 0)}× maior</em><div class="meter"><i style="width:100%"></i></div><audio controls preload="none" src="audio/trilha_renderizada.wav"></audio></div>
    <div class="pl"><b>bateria.mid (do grupo)</b><em>${kb(bm)} para ${nf(bat.meta.duracao)} s de música · em WAV de CD seriam ≈ ${nf(bat.meta.duracao * 176400 / 1048576, 1)} MB</em></div>`;
  pararTudo.push(() => pararMidi('trilha'));
  const lo = Math.min(...song.notas.map(n => n.nota)) - 2, hi = Math.max(...song.notas.map(n => n.nota)) + 2;
  anims.push({ tela: 'midi', fn: () => {
    const { g } = c, W = c.W(), H = c.H(), ink = cssv('--ink'), mut = cssv('--mut'), ln = cssv('--line');
    g.clearRect(0, 0, W, H);
    const tp = tocadores.melodia.p, pos = tp ? tp.posicao() : -1, X = t => 8 + t / m.duracao * (W - 16), rowH = (H - 16) / (hi - lo);
    g.strokeStyle = ln; g.lineWidth = 1;
    for (let k = 0; k <= 8; k++) { const x = X(k * m.duracao / 8); g.beginPath(); g.moveTo(x, 4); g.lineTo(x, H - 4); g.stroke(); }
    for (const n of song.notas) {
      const y = 8 + (hi - n.nota) * rowH, x = X(n.t), w = Math.max(3, X(n.t + n.d) - x - 1), ativa = pos >= n.t && pos < n.t + n.d;
      g.fillStyle = ativa ? ink : n.ch === 1 ? ln : mut;
      g.globalAlpha = ativa ? 1 : n.ch === 2 ? .55 : .85;
      g.fillRect(x, y - rowH * .45, w, Math.max(3, rowH * .9));
    }
    g.globalAlpha = 1;
    if (pos >= 0) { g.fillStyle = ink; g.fillRect(X(pos % m.duracao), 0, 2, H); }
    g.fillStyle = mut; g.font = '600 12px Outfit, sans-serif';
    g.fillText('melodia · arpejo · baixo — cada retângulo é um evento MIDI', 12, H - 8);
  } });
}
/* bateria do grupo: grade de passos que acompanha a música, 2 compassos por vez */
{
  const m = bat.meta, c = canvas($('#cvBat'));
  tocador('bat', bat, { kit: true }, $('#bBat'), 'Tocar bateria');
  tocador('batPiano', bat, { kit: false }, $('#bBatPiano'), 'Tocar como piano');
  $('#bBat').addEventListener('click', () => alternar('bat'));
  $('#bBatPiano').addEventListener('click', () => alternar('batPiano'));
  const faixas = [...new Set(bat.notas.map(n => n.trk))].sort((a, b) => a - b);
  const vazias = m.faixas - faixas.length;  // E-Piano, Bass Slap e Strings estão sem notas
  $('#oBatInfo').textContent = `${bat.notas.length} notas · ${faixas.length} faixas com notas (${vazias > 0 ? vazias + ' vazias' : 'nenhuma vazia'}) · ${m.bpm} bpm · ${nf(m.duracao)} s`;
  const NOME = { bumbo: 'Bumbo', caixa: 'Caixa', chimbal: 'Chimbal fechado', chimbalAberto: 'Chimbal aberto' };
  const rotulo = t => { const n = m.nomes[t] || 'faixa ' + t, p = DM.peca(n); return (p ? NOME[p] : n) + ' · ' + n; };
  const janela = 2 * m.compasso, passo = m.compasso / 16;
  anims.push({ tela: 'midi', fn: () => {
    const { g } = c, W = c.W(), H = c.H(), ink = cssv('--ink'), mut = cssv('--mut'), ln = cssv('--line');
    g.clearRect(0, 0, W, H);
    const pos = posBat(), p = pos >= 0 ? pos % m.duracao : 0, ini = Math.floor(p / janela) * janela;
    const estreito = W < 560, L = estreito ? 14 : 250, rowH = (H - 34) / faixas.length, X = t => L + (t - ini) / janela * (W - L - 10);
    for (let k = 0; k <= 32; k++) { const x = X(ini + k * passo); g.fillStyle = k % 16 === 0 ? mut : k % 4 === 0 ? ln : ln; g.globalAlpha = k % 4 === 0 ? 1 : .45; g.fillRect(x, 6, 1, H - 34); }
    g.globalAlpha = 1;
    faixas.forEach((t, r) => {
      const y = 6 + r * rowH;
      if (!estreito) { g.fillStyle = mut; g.font = '600 13px Outfit, sans-serif'; g.fillText(rotulo(t), 8, y + rowH / 2 + 4); }
      for (const n of bat.notas) {
        if (n.trk !== t || n.t < ini || n.t >= ini + janela) continue;
        const ativa = pos >= 0 && p >= n.t && p < n.t + 0.12, lado = Math.min(rowH * .7, (W - L) / 32 * .9) * (0.45 + 0.55 * n.vel / 127);
        g.fillStyle = ativa ? ink : mut; g.globalAlpha = ativa ? 1 : .35 + .5 * n.vel / 127;
        g.fillRect(X(n.t) - lado / 2, y + (rowH - lado) / 2, lado, lado);
      }
      g.globalAlpha = 1;
    });
    if (pos >= 0) { g.fillStyle = ink; g.fillRect(X(p), 2, 2, H - 26); }
    g.fillStyle = mut; g.font = '600 12px Outfit, sans-serif';
    g.fillText(`compassos ${nf(ini / m.compasso + 1)}–${nf(ini / m.compasso + 2)} de ${nf(m.duracao / m.compasso)}` + (estreito ? ' · bumbo, caixas, chimbais' : ' · quadrado maior = batida mais forte (velocity)'), 8, H - 8);
  } });
}
/* música de fundo: a bateria do grupo em loop, com volume baixo.
   Começa na primeira interação (o navegador não deixa tocar som antes disso),
   pausa enquanto outra mídia ou demonstração toca e volta sozinha depois.
   O botão "Trilha" do topo liga e desliga. */
let narrando = false;
const fundo = { ligado: store.get('dgg-musica-fundo', true), p: null, iniciado: false };
const VOL_FUNDO = 0.12;
function midiaTocando() {
  for (const id in tocadores) { const t = tocadores[id]; if (t.p && t.p.on) return true; }
  if (narrando) return true;
  return $$('audio, video:not([data-gesto])').some(m => !m.paused && !m.ended);
}
function syncFundo() {
  const bt = $('#btnTrilha'); bt.setAttribute('aria-pressed', String(fundo.ligado));
  if (!fundo.iniciado) return;
  const deve = fundo.ligado && !midiaTocando() && document.visibilityState === 'visible';
  if (deve && !(fundo.p && fundo.p.on)) {
    if (!fundo.p) { fundo.p = new DM.Player(ac(), bat, { kit: true }); fundo.p.out.gain.value = VOL_FUNDO; }
    fundo.p.tocar();
  } else if (!deve && fundo.p && fundo.p.on) fundo.p.parar();
}
{
  const bt = $('#btnTrilha');
  bt.title = 'Música de fundo: bateria do grupo (LMMS) — clique para ligar/desligar';
  const inicia = () => { if (fundo.iniciado) return; fundo.iniciado = true; ac(); carregaSomBotao(); setTimeout(syncFundo, 0); };
  ['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, inicia, { capture: true, once: true }));
  bt.addEventListener('click', () => { fundo.ligado = !fundo.ligado; store.set('dgg-musica-fundo', fundo.ligado); fundo.iniciado = true; syncFundo(); });
  document.addEventListener('play', e => { if (e.target.dataset && 'gesto' in e.target.dataset) return; pararMidi(); syncFundo(); }, true);
  ['pause', 'ended'].forEach(ev => document.addEventListener(ev, () => setTimeout(syncFundo, 50), true));
  document.addEventListener('visibilitychange', syncFundo);
  pararTudo.push(() => setTimeout(syncFundo, 0));
  syncFundo();
}

/* ---------- Narração (arquivo gravado pelo grupo; se faltar, voz sintetizada) ---------- */
{
  let falando = null;
  const pararN = () => { narrando = false; setTimeout(syncFundo, 0); if (falando) { falando.pause && falando.pause(); falando = null; } try { speechSynthesis.cancel(); } catch (e) { } $$('.narrar').forEach(b => b.setAttribute('aria-pressed', 'false')); };
  pararTudo.push(pararN);
  $$('.narrar').forEach(b => b.addEventListener('click', () => {
    if (b.getAttribute('aria-pressed') === 'true') return pararN();
    pararN(); b.setAttribute('aria-pressed', 'true'); narrando = true; syncFundo();
    const tela = b.closest('.tela'), id = tela.id.slice(2), txt = $('.intro', tela).textContent;
    const a = new Audio('audio/narracao_' + id + '.mp3'); falando = a;
    const fala = () => { try { const u = new SpeechSynthesisUtterance(txt); u.lang = 'pt-BR'; u.onend = () => { b.setAttribute('aria-pressed', 'false'); narrando = false; syncFundo(); }; speechSynthesis.speak(u); } catch (e) { b.setAttribute('aria-pressed', 'false'); } };
    a.addEventListener('ended', () => { b.setAttribute('aria-pressed', 'false'); narrando = false; syncFundo(); });
    a.addEventListener('error', () => { if (falando === a) fala(); });
    a.play().catch(() => { });
  }));
}

/* ---------- QUIZ ---------- */
const quiz = { ativo: false };
const NOMES = { som: 'Módulo 1 · O que é o som', digital: 'Módulo 2 · Do analógico ao digital', tamanho: 'Módulo 3 · Tamanho e qualidade', formatos: 'Módulo 4 · Formatos e compressão', edicao: 'Módulo 5 · Editando áudio', midi: 'Módulo 6 · Áudio digital × MIDI' };
const embaralha = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const QN = 5;
function novoQuiz() {
  const banco = window.DGG_PERGUNTAS;
  quiz.ativo = true; quiz.i = 0; quiz.acertos = 0; quiz.resp = [];
  quiz.qs = embaralha(banco).slice(0, QN).map(q => {
    const ops = q.ops.map((t, k) => ({ t, certa: k === q.c }));
    return { ...q, ops: q.vf ? ops : embaralha(ops) };
  });
  mostra();
}
function mostra() {
  const box = $('#quizBox'), q = quiz.qs[quiz.i], letras = q.vf ? ['V', 'F'] : ['A', 'B', 'C', 'D'];
  box.innerHTML = `<div class="qmeta"><span>Pergunta ${quiz.i + 1} de ${QN}</span><span>${q.vf ? 'Verdadeiro ou falso' : 'Múltipla escolha'} · ${quiz.acertos} acerto${quiz.acertos === 1 ? '' : 's'}</span></div>
    <div class="qbar"><i style="width:${quiz.i / QN * 100}%"></i></div>
    <h2>${esc(q.p)}</h2>
    ${q.img ? `<div class="qmedia"><img src="${esc(q.img)}" alt="Imagem da pergunta"></div>` : ''}
    ${q.audio ? `<div class="qmedia"><audio controls preload="none" src="${esc(q.audio)}"></audio></div>` : ''}
    <div class="opts">${q.ops.map((o, k) => `<button class="opt" data-k="${k}"><span class="l">${letras[k]}</span><span>${esc(o.t)}</span></button>`).join('')}</div>
    <div id="qfb"></div>`;
  $$('.opt', box).forEach(b => b.addEventListener('click', () => responde(+b.dataset.k)));
}
function responde(k) {
  const q = quiz.qs[quiz.i], ok = q.ops[k].certa, box = $('#quizBox');
  $$('.opt', box).forEach((b, j) => { b.disabled = true; if (q.ops[j].certa) b.classList.add('certa'); else if (j === k) b.classList.add('errada'); });
  $$('audio', box).forEach(a => a.pause());
  if (ok) quiz.acertos++;
  quiz.resp.push({ p: q.p, ok, mod: q.mod });
  sfx(ok ? 'acerto' : 'erro');
  const ult = quiz.i === QN - 1;
  $('#qfb').innerHTML = `<div class="fb fb-gesto"><video class="gesto" data-gesto src="video/gesto_${ok ? 'cima' : 'baixo'}.mp4" muted playsinline autoplay preload="auto" aria-label="${ok ? 'Polegar para cima' : 'Polegar para baixo'}"></video>
    <div><b class="${ok ? 'ok' : 'no'}">${ok ? 'Acertou!' : 'Não foi dessa vez.'}</b>${esc(q.ex)} <a href="#${q.mod}">Revisar: ${NOMES[q.mod]}</a></div></div>
    <button class="btn" id="bProx">${ult ? 'Ver resultado' : 'Próxima pergunta →'}</button>`;
  $('#bProx').addEventListener('click', () => { if (ult) final(); else { quiz.i++; mostra(); } });
  const vg = $('#qfb video.gesto'); if (vg) vg.play().catch(() => { });
  $('#bProx').focus();
}
function final() {
  const p = Math.round(quiz.acertos / QN * 100), rec = Math.max(p, store.get('dgg-recorde', 0));
  store.set('dgg-recorde', rec); sfx('fim');
  const msg = p === 100 ? 'Perfeito! Você domina o áudio digital.' : p >= 60 ? 'Muito bem! Revise os pontos marcados para chegar aos 100%.' : 'Vale revisar os módulos e tentar de novo — as perguntas mudam a cada rodada.';
  $('#quizBox').innerHTML = `<div class="final"><div class="qbar"><i style="width:100%"></i></div>
    <div class="gif-fim" id="gifFim"><img src="img/animacao_audio.gif?r=${Date.now()}" alt="Animação de conclusão do quiz" width="220" height="220"></div>
    <p style="margin:0 auto;color:var(--mut);font-weight:600">Seu resultado</p><div class="big">${p}%</div>
    <h2>${quiz.acertos} de ${QN} acertos</h2><p style="margin:0 auto 18px">${msg} Seu recorde neste navegador: ${rec}%.</p>
    <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap"><button class="btn" id="bDeNovo">Nova rodada (novas perguntas)</button><a class="btn alt" href="#inicio">Voltar aos módulos</a></div>
    <ol class="rev">${quiz.resp.map(r => `<li><span class="${r.ok ? 'ok' : 'no'}">${r.ok ? 'Certa' : 'Errada'}</span> — ${esc(r.p)} ${r.ok ? '' : `<a href="#${r.mod}">revisar</a>`}</li>`).join('')}</ol></div>`;
  $('#bDeNovo').addEventListener('click', novoQuiz);
  clearTimeout(final.t); final.t = setTimeout(() => { const g = $('#gifFim'); if (g) { g.classList.add('some'); setTimeout(() => g.remove(), 600); } }, 6000);
  quiz.ativo = false;
}

/* áudio que não carrega (ex.: FLAC na versão hospedada) */
document.addEventListener('error', e => { const a = e.target; if (a.tagName === 'AUDIO' && !a.dataset.aviso) { a.dataset.aviso = 1;
  a.insertAdjacentHTML('afterend', '<small style="grid-column:1/-1;color:var(--mut)">Este arquivo não pôde ser reproduzido aqui; abra a versão offline (pasta do projeto) para ouvi-lo.</small>'); } }, true);

/* ---------- partida ---------- */
rota();
if (reduz) setInterval(() => anims.forEach(a => a.tela === atual && a.fn(performance.now() / 1000)), 250);
else requestAnimationFrame(loop);
}
