/* DggSounds — leitor de arquivos MIDI (SMF) e sintetizador simples em Web Audio */
window.DggMidi = (function () {
  function b64(s) { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }

  // Lê um Standard MIDI File e devolve as notas em segundos
  function parse(bytes) {
    let p = 0;
    const u32 = () => (bytes[p++] << 24 | bytes[p++] << 16 | bytes[p++] << 8 | bytes[p++]) >>> 0;
    const u16 = () => bytes[p++] << 8 | bytes[p++];
    const vlq = () => { let v = 0, c; do { c = bytes[p++]; v = (v << 7) | (c & 0x7f); } while (c & 0x80); return v; };
    p = 8; const fmt = u16(), ntrk = u16(), tpq = u16();
    let tempo = 500000; const raw = [], meta = { nome: '', nomes: [], formato: fmt, faixas: ntrk, tpq, eventos: 0 };
    for (let t = 0; t < ntrk; t++) {
      p += 4; const len = u32(), end = p + len; let tick = 0, run = 0; const on = {};
      while (p < end) {
        tick += vlq(); let st = bytes[p];
        if (st & 0x80) p++; else st = run;
        meta.eventos++;
        if (st === 0xff) { const ty = bytes[p++], l = vlq();
          if (ty === 0x51) tempo = bytes[p] << 16 | bytes[p + 1] << 8 | bytes[p + 2];
          if (ty === 0x03) { meta.nome = String.fromCharCode(...bytes.slice(p, p + l)); meta.nomes[t] = meta.nome; }
          p += l; continue; }
        if (st === 0xf0 || st === 0xf7) { p += vlq(); continue; }
        run = st; const ty = st & 0xf0, ch = st & 15;
        if (ty === 0xc0 || ty === 0xd0) { p++; continue; }
        const a = bytes[p++], v = bytes[p++];
        if (ty === 0x90 && v > 0) on[ch + ':' + a] = { tick, vel: v };
        else if (ty === 0x80 || ty === 0x90) { const k = ch + ':' + a, o = on[k];
          if (o) { raw.push({ trk: t, ch, nota: a, ini: o.tick, fim: tick, vel: o.vel }); delete on[k]; } }
      }
      p = end;
    }
    const s = tempo / 1e6 / tpq;
    const notas = raw.map(n => ({ trk: n.trk, ch: n.ch, nota: n.nota, vel: n.vel, t: n.ini * s, d: (n.fim - n.ini) * s })).sort((a, b) => a.t - b.t);
    meta.compasso = 4 * 60 / Math.round(60e6 / tempo);
    meta.bpm = Math.round(60e6 / tempo);
    meta.duracao = Math.ceil(Math.max(...notas.map(n => n.t + n.d)) / (60 / meta.bpm) / 4) * 4 * (60 / meta.bpm);
    return { notas, meta };
  }

  const TIMBRE = { 0: ['square', 0.07], 1: ['triangle', 0.09], 2: ['sawtooth', 0.11] };
  const hz = n => 440 * Math.pow(2, (n - 69) / 12);

  // tipo de peça de bateria a partir do nome da faixa (no LMMS cada faixa é um sample)
  function peca(nome) {
    nome = nome || '';
    if (/\bBD\b|kick|bumbo/i.test(nome)) return 'bumbo';
    if (/snare|caixa/i.test(nome)) return 'caixa';
    if (/open/i.test(nome)) return 'chimbalAberto';
    if (/hi.?h?hat|chimbal|hat/i.test(nome)) return 'chimbal';
    return null;
  }
  let ruido = null;
  function ruidoBuf(c) {
    if (ruido && ruido.sampleRate === c.sampleRate) return ruido;
    ruido = c.createBuffer(1, c.sampleRate, c.sampleRate); const d = ruido.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return ruido;
  }
  function Player(ctx, song, opc) {
    this.kit = !(opc && opc.kit === false);
    this.ctx = ctx; this.song = song; this.on = false; this.vozes = []; this.out = ctx.createGain(); this.out.gain.value = 0.8;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3800; this.out.connect(lp); lp.connect(ctx.destination);
  }
  Player.prototype.agendar = function (t0) {
    const c = this.ctx;
    for (const n of this.song.notas) {
      const tipo = this.kit ? peca(this.song.meta.nomes[n.trk]) : null;
      if (tipo) { this.bateria(tipo, t0 + n.t, n.vel / 127); continue; }
      const [w, g] = this.kit ? (TIMBRE[n.ch] || ['sine', 0.08]) : ['triangle', 0.05], o = c.createOscillator(), a = c.createGain(), s = t0 + n.t, e = s + n.d;
      o.type = w; o.frequency.value = hz(n.nota);
      const pk = g * n.vel / 127;
      a.gain.setValueAtTime(0, s); a.gain.linearRampToValueAtTime(pk, s + 0.01);
      a.gain.setTargetAtTime(pk * 0.6, s + 0.02, 0.08); a.gain.setTargetAtTime(0, e, 0.04);
      o.connect(a); a.connect(this.out); o.start(s); o.stop(e + 0.3); this.vozes.push(o);
    }
  };
  Player.prototype.bateria = function (tipo, s, v) {
    const c = this.ctx, out = this.out, vozes = this.vozes;
    const env = (g, pico, dec) => { g.gain.setValueAtTime(pico, s); g.gain.exponentialRampToValueAtTime(0.0008, s + dec); };
    const ruidoF = (tipoF, freq, pico, dec) => {
      const r = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      r.buffer = ruidoBuf(c); f.type = tipoF; f.frequency.value = freq; env(g, pico, dec);
      r.connect(f); f.connect(g); g.connect(out); r.start(s); r.stop(s + dec + 0.02); vozes.push(r);
    };
    if (tipo === 'bumbo') {
      const o = c.createOscillator(), g = c.createGain();
      o.frequency.setValueAtTime(150, s); o.frequency.exponentialRampToValueAtTime(45, s + 0.12);
      env(g, 0.9 * v, 0.35); o.connect(g); g.connect(out); o.start(s); o.stop(s + 0.4); vozes.push(o);
    } else if (tipo === 'caixa') {
      ruidoF('highpass', 1200, 0.45 * v, 0.18);
      const o = c.createOscillator(), g = c.createGain(); o.type = 'triangle'; o.frequency.value = 190;
      env(g, 0.3 * v, 0.1); o.connect(g); g.connect(out); o.start(s); o.stop(s + 0.12); vozes.push(o);
    } else ruidoF('highpass', 7000, (tipo === 'chimbal' ? 0.22 : 0.18) * v, tipo === 'chimbal' ? 0.05 : 0.32);
  };
  Player.prototype.tocar = function () {
    if (this.on) return; this.on = true;
    const loop = () => {
      if (!this.on) return;
      this.t0 = this.ctx.currentTime + 0.08; this.vozes = this.vozes.slice(-400); this.agendar(this.t0);
      this.timer = setTimeout(loop, this.song.meta.duracao * 1000 - 60);
    };
    loop();
  };
  Player.prototype.parar = function () {
    this.on = false; clearTimeout(this.timer);
    for (const o of this.vozes) { try { o.stop(); } catch (e) { } }
    this.vozes = [];
  };
  Player.prototype.posicao = function () { return this.on ? Math.max(0, this.ctx.currentTime - this.t0) : -1; };

  return { parse, b64, Player, peca };
})();
